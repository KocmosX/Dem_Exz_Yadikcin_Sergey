﻿using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private readonly DatabaseContext _context;

        public MainWindow()
        {
            InitializeComponent();
            _context = new DatabaseContext();
            LoadPartners();
        }

        private void LoadPartners()
        {
            var partners = _context.GetPartners();
            foreach (var partner in partners)
            {
                // Рассчитайте скидку для каждого партнера
                partner.Discount = _context.CalculateDiscount(partner.PartnerID);
            }
            PartnersListBox.ItemsSource = partners;
        }

        private void AddPartnerButton_Click(object sender, RoutedEventArgs e)
        {
            var editWindow = new PartnerEditWindow(_context);
            if (editWindow.ShowDialog() == true)
            {
                LoadPartners();
            }
        }

        private void EditPartnerButton_Click(object sender, RoutedEventArgs e)
        {
            if (PartnersListBox.SelectedItem is Partner selectedPartner)
            {
                var editWindow = new PartnerEditWindow(_context, selectedPartner);
                if (editWindow.ShowDialog() == true)
                {
                    LoadPartners();
                }
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            PartnersListBox.Visibility = Visibility.Visible;
            EditPartnerButton.Visibility = Visibility.Visible;
            BackButton.Visibility = Visibility.Collapsed;
        }

        private void PartnersListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            EditPartnerButton.IsEnabled = PartnersListBox.SelectedItem != null;
        }
        private void ViewSalesHistoryButton_Click(object sender, RoutedEventArgs e)
        {
            if (PartnersListBox.SelectedItem is Partner selectedPartner)
            {
                var salesHistory = _context.GetSalesHistory(selectedPartner.PartnerID);
                var historyWindow = new SalesHistoryWindow(salesHistory);
                historyWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите партнера.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}