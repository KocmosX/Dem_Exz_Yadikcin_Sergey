﻿using System.Collections.Generic;
using System.Windows;

namespace WpfApp1
{
    public partial class SalesHistoryWindow : Window
    {
        public SalesHistoryWindow(List<SalesHistory> salesHistory)
        {
            InitializeComponent();
            SalesHistoryListBox.ItemsSource = salesHistory;
        }
    }

    public class SalesHistory
    {
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public System.DateTime SaleDate { get; set; }
    }
}
