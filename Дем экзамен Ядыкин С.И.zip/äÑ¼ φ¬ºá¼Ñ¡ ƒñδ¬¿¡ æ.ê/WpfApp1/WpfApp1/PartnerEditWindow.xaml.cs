﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    public partial class PartnerEditWindow : Window
    {
        private readonly DatabaseContext _context;
        private Partner _partner;

        public PartnerEditWindow(DatabaseContext context, Partner partner = null)
        {
            InitializeComponent();
            _context = context;
            _partner = partner ?? new Partner();

            // Загрузка данных в поля, если редактируем существующего партнера
            if (_partner.PartnerID > 0)
            {
                CompanyNameTextBox.Text = _partner.CompanyName;
                PartnerTypeComboBox.SelectedItem = _partner.PartnerType;
                RatingTextBox.Text = _partner.Rating.ToString();
                LegalAddressTextBox.Text = _partner.LegalAddress;
                DirectorNameTextBox.Text = _partner.DirectorName;
                PhoneTextBox.Text = _partner.Phone;
                EmailTextBox.Text = _partner.Email;
                INNTextBox.Text = _partner.INN;
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверка корректности введенных данных
                if (string.IsNullOrWhiteSpace(CompanyNameTextBox.Text) ||
                    PartnerTypeComboBox.SelectedItem == null ||
                    !int.TryParse(RatingTextBox.Text, out int rating) ||
                    rating < 1 || rating > 5 || // Убедитесь, что это условие соответствует вашему ограничению
                    string.IsNullOrWhiteSpace(LegalAddressTextBox.Text) ||
                    string.IsNullOrWhiteSpace(DirectorNameTextBox.Text) ||
                    string.IsNullOrWhiteSpace(INNTextBox.Text))
                {
                    MessageBox.Show("Пожалуйста, заполните все поля корректно. Значение 'Рейтинг' должно быть в диапазоне от 1 до 5.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Сохранение данных партнера
                _partner.CompanyName = CompanyNameTextBox.Text;
                _partner.PartnerType = (PartnerTypeComboBox.SelectedItem as ComboBoxItem).Content.ToString();
                _partner.Rating = rating;
                _partner.LegalAddress = LegalAddressTextBox.Text;
                _partner.DirectorName = DirectorNameTextBox.Text;
                _partner.Phone = PhoneTextBox.Text;
                _partner.Email = EmailTextBox.Text;
                _partner.INN = INNTextBox.Text;

                _context.SavePartner(_partner);
                MessageBox.Show("Данные партнера сохранены.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}