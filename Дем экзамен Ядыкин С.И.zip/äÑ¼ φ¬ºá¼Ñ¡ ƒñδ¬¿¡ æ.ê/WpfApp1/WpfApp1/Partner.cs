﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class Partner
    {
        public int PartnerID { get; set; }
        public string PartnerType { get; set; }
        public string CompanyName { get; set; }
        public string LegalAddress { get; set; }
        public string INN { get; set; }
        public string DirectorName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public byte[] Logo { get; set; }
        public int? Rating { get; set; }
        public string SalesLocations { get; set; }

        // Свойство для хранения скидки
        public decimal Discount { get; set; }
    }

}
