﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.Entity.Core.EntityClient;
using System.Windows;
using WpfApp1;

public class DatabaseContext
{
    private readonly string _connectionString;

    public DatabaseContext()
    {
        // Получаем строку подключения для Entity Framework
        var entityConnectionString = ConfigurationManager.ConnectionStrings["PartnerManagementEntities"].ConnectionString;

        // Извлекаем строку подключения для SqlConnection
        var entityConnection = new EntityConnectionStringBuilder(entityConnectionString);
        _connectionString = entityConnection.ProviderConnectionString;
    }

    public List<Partner> GetPartners()
    {
        var partners = new List<Partner>();
        try
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT * FROM Partners", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var partner = new Partner
                            {
                                PartnerID = reader.GetInt32(0),
                                PartnerType = reader.GetString(1),
                                CompanyName = reader.GetString(2),
                                LegalAddress = reader.GetString(3),
                                INN = reader.GetString(4),
                                DirectorName = reader.GetString(5),
                                Phone = reader.IsDBNull(6) ? null : reader.GetString(6),
                                Email = reader.IsDBNull(7) ? null : reader.GetString(7),
                                Logo = reader.IsDBNull(8) ? null : (byte[])reader[8],
                                Rating = reader.IsDBNull(9) ? (int?)null : reader.GetInt32(9),
                                SalesLocations = reader.IsDBNull(10) ? null : reader.GetString(10)
                            };
                            partners.Add(partner);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка при получении данных партнеров: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        return partners;
    }

    public void SavePartner(Partner partner)
    {
        try
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var commandText = partner.PartnerID > 0
                    ? "UPDATE Partners SET CompanyName = @CompanyName, LegalAddress = @LegalAddress, PartnerType = @PartnerType, Rating = @Rating, DirectorName = @DirectorName, Phone = @Phone, Email = @Email, INN = @INN WHERE PartnerID = @PartnerID"
                    : "INSERT INTO Partners (CompanyName, LegalAddress, PartnerType, Rating, DirectorName, Phone, Email, INN) VALUES (@CompanyName, @LegalAddress, @PartnerType, @Rating, @DirectorName, @Phone, @Email, @INN)";

                using (var command = new SqlCommand(commandText, connection))
                {
                    command.Parameters.AddWithValue("@CompanyName", partner.CompanyName);
                    command.Parameters.AddWithValue("@LegalAddress", partner.LegalAddress);
                    command.Parameters.AddWithValue("@PartnerType", partner.PartnerType);
                    command.Parameters.AddWithValue("@Rating", partner.Rating);
                    command.Parameters.AddWithValue("@DirectorName", partner.DirectorName);
                    command.Parameters.AddWithValue("@Phone", partner.Phone ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@Email", partner.Email ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@INN", partner.INN);

                    if (partner.PartnerID > 0)
                    {
                        command.Parameters.AddWithValue("@PartnerID", partner.PartnerID);
                    }

                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка при сохранении данных партнера: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    public decimal CalculateDiscount(int partnerId)
    {
        decimal totalQuantity = 0;
        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            using (var command = new SqlCommand("SELECT SUM(Quantity) FROM SalesHistory WHERE PartnerID = @PartnerID", connection))
            {
                command.Parameters.AddWithValue("@PartnerID", partnerId);
                var result = command.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    totalQuantity = Convert.ToDecimal(result);
                }
            }
        }

        if (totalQuantity < 10000)
            return 0;
        else if (totalQuantity < 50000)
            return 5;
        else if (totalQuantity < 300000)
            return 10;
        else
            return 15;
    }

    public List<SalesHistory> GetSalesHistory(int partnerId)
    {
        var salesHistory = new List<SalesHistory>();
        try
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT ProductName, Quantity, SaleDate FROM SalesHistory WHERE PartnerID = @PartnerID", connection))
                {
                    command.Parameters.AddWithValue("@PartnerID", partnerId);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var history = new SalesHistory
                            {
                                ProductName = reader.GetString(0),
                                Quantity = reader.GetInt32(1),
                                SaleDate = reader.GetDateTime(2)
                            };
                            salesHistory.Add(history);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка при получении истории реализации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        return salesHistory;
    }

    public int CalculateMaterialRequired(int productTypeId, int materialTypeId, int quantity, double param1, double param2)
    {
        // Примерные значения коэффициентов и процентов брака
        var productCoefficients = new Dictionary<int, double>
        {
            { 1, 1.2 }, // Пример для типа продукции 1
            { 2, 1.5 }  // Пример для типа продукции 2
        };

        var materialWastePercentages = new Dictionary<int, double>
        {
            { 1, 0.05 }, // 5% брака для типа материала 1
            { 2, 0.10 }  // 10% брака для типа материала 2
        };

        if (!productCoefficients.TryGetValue(productTypeId, out var productCoefficient) ||
            !materialWastePercentages.TryGetValue(materialTypeId, out var wastePercentage))
        {
            return -1;
        }

        var materialPerUnit = param1 * param2 * productCoefficient;
        var totalMaterial = materialPerUnit * quantity;
        var materialWithWaste = totalMaterial * (1 + wastePercentage);

        return (int)Math.Ceiling(materialWithWaste);
    }
}
